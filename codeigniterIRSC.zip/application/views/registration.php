<!DOCTYPE html>
<html>
<head>
<title>Registration form</title>
</head>

<body>
<?php echo validation_errors(); ?>  
<h2>Registration Form</h2>
	<form method="post">
		<table width="500" border="1" cellspacing="5" cellpadding="5">
  <tr>
    <td width="230">Name </td>
    <td width="329"><input type="text" name="name"/></td>
  </tr>
  <tr>
    <td>Email Id </td>
    <td><input type="text" name="email"/></td>
  </tr>
  <tr>
    <td>Mobile No </td>
    <td><input type="text" name="mobile"/></td>
  </tr>
  <tr>
    <td>Date of Birth </td>
    <td><input type="text" name="dob"/></td>
  </tr>
  <tr>
    <td>PinCode </td>
    <td><input type="text" name="pincode"/></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><input type="submit" name="save" value="Submit"/></td>
  </tr>
</table>

	</form>
</body>
</html>