<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rohit extends CI_Controller 
{
	public function __construct()
	{
	parent::__construct();
	$this->load->database();
	$this->load->helper('url');
	$this->load->model('Rohit_Model');
	}

	public function savedata()
	{   
        $this->load->library('form_validation');

        $this->form_validation->set_rules('name', 'Name ','trim|required|alpha_numeric_spaces');
        $this->form_validation->set_rules('email', 'Email Id ','trim|required|valid_email');
        $this->form_validation->set_rules('mobile', 'Mobile No ','trim|required|numeric|exact_length[10]');
        $this->form_validation->set_rules('dob', 'Date of Birth ','trim|required');
        $this->form_validation->set_rules('pincode', 'PinCode ','trim|required|numeric|exact_length[6]');

		
        if ($this->form_validation->run() == TRUE)
        {
			echo 'Form is validated';
			if($this->input->post('save'))
            {
            $n=$this->input->post('name');
            $e=$this->input->post('email');
            $m=$this->input->post('mobile');
            $d=$this->input->post('dob');
            $p=$this->input->post('pincode');
            $this->Rohit_Model->saverecords($n,$e,$m,$d,$p);
            	
            }
			redirect("Rohit/dispdata");  
		}

		$this->load->view('registration');
           
		
	}
	
	public function dispdata()
	{
	$result['data']=$this->Rohit_Model->displayrecords();
	$this->load->view('display_records',$result);
	
	}
	
	public function deletedata()
	{
	$id=$this->input->get('id');
	$this->Rohit_Model->deleterecords($id);
	redirect("Rohit/dispdata");

	}
	
	public function updatedata()
	{
	$id=$this->input->get('id');
	$result['data']=$this->Rohit_Model->displayrecordsById($id);
	$this->load->view('update_records',$result);	
	
		if($this->input->post('update'))
		{
		$n=$this->input->post('name');
		$e=$this->input->post('email');
        $m=$this->input->post('mobile');
        $d=$this->input->post('dob');
        $p=$this->input->post('pincode');
		$this->Rohit_Model->updaterecords($n,$e,$m,$d,$p,$id);
		redirect("Rohit/dispdata");
		}
	}
}
