<?php
class Rohit_Model extends CI_Model 
{
	function saverecords($name,$email,$mobile,$dob,$pincode)
	{
	$query="insert into users values('','$name','$email','$mobile','$dob','$pincode')";
	$this->db->query($query);
	}
	
	function displayrecords()
	{
	$query=$this->db->query("select * from users");
	return $query->result();
	}
	
	function deleterecords($id)
	{
	$this->db->query("delete  from users where user_id='".$id."'");
	}
	
	function displayrecordsById($id)
	{
	$query=$this->db->query("select * from users where user_id='".$id."'");
	return $query->result();
	}
	
	function updaterecords($name,$email,$mobile,$dob,$pincode,$id)
	{
	$query=$this->db->query("update users SET name='$name',email='$email',mobile='$mobile',dob='$dob',pincode='$pincode' where user_id='".$id."'");
	}	
}
?>